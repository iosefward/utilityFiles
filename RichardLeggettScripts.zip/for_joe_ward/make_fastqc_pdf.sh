#!/bin/bash

# File:    make_fastqc_pdf.sh
# Purpose: Make a PDF containing all the FASTQC graphs and summary information
# Author:  Richard Leggett

source seqops.sh

pap_folder="PAP"
run_dir=""
fastqc_dir=""
latex_file=""
output_dir="."
email=0
samplesheet="SampleSheet.csv"

# ----------------------------------------------------------------------
# Function: usage
# Purpose:  Print usage text
# ----------------------------------------------------------------------
function usage
{
cat << EOF
usage: $0 < -o seqop | -d dir > < -l file > < -p dir >

Creates PDF of FASTQC report.

Options:
    -o  SEQOP number, or specify -d
    -d  FASTQC directory
    -h  Show this message
    -l  LaTeX output filename (.tex)
    -p  PDF output directory
    -s  Sample sheet name (default SampleSheet.csv)

EOF
}

# ----------------------------------------------------------------------
# Function: check_for_files
# Purpose:  Check for FASTQC image files etc.
# ----------------------------------------------------------------------
function check_for_files
{
    dirname=$1
    images_dir=${dirname}/Images
    
    if [ ! -d ${dirname} ] ; then echo "Error: can't find ${dirname}" ; exit 2 ; fi
    if [ ! -d ${images_dir} ] ; then echo "Error: can't find ${images_dir}" ; exit 2 ; fi
    if [ ! -f ${dirname}/fastqc_data.txt ] ; then echo "Error: can't find ${dirname}/fastqc_data.txt" ; exit 2; fi 
}

# ----------------------------------------------------------------------
# Function: output_latex_header
# Purpose:  Ouput preamble to LaTeX file
# ----------------------------------------------------------------------
function output_latex_header
{
    echo "\\documentclass[a4paper,11pt,oneside]{article}" > ${latex_file}
    echo "\\usepackage{graphicx}" >> ${latex_file}
    echo "\\usepackage{url}" >> ${latex_file}
    echo "\\usepackage{subfigure}" >> ${latex_file}
    echo "\\usepackage{rotating}" >> ${latex_file}
    echo "\\usepackage{color}" >> ${latex_file}
    echo "\\usepackage[portrait,top=1cm, bottom=2cm, left=1cm, right=1cm]{geometry}" >> ${latex_file}
    echo "\\begin{document}" >> ${latex_file}
    echo "\\renewcommand*{\familydefault}{\sfdefault}" >> ${latex_file}
}

# ----------------------------------------------------------------------
# Function: output_latex_footer
# Purpose:  End LaTeX document
# ----------------------------------------------------------------------
function output_latex_footer
{
    echo "\\end{document}" >> ${latex_file}
}

# ----------------------------------------------------------------------
# Function: output_latex_for_dir
# Purpose:  Output the LaTeX markup for a specific FASTQC directory
# ----------------------------------------------------------------------
function output_latex_for_dir
{
    header_prefix=$1
    dirname=$2

    gz_filename=`grep -A 8 'Basic Statistics' ${dirname}/fastqc_data.txt | grep 'Filename' | perl -nae 'my @arr=split(/\t/); $arr[1]=~s/_/\\\_/g ; print $arr[1]'`


    echo "\\section*{\large{${header_prefix}${gz_filename}}}" >> ${latex_file}

    echo "\\begin{figure}[h!]" >> ${latex_file}
    echo "\\centering" >> ${latex_file}

    for file in per_base_quality.png per_sequence_quality.png per_base_sequence_content.png per_base_gc_content.png per_sequence_gc_content.png per_base_n_content.png sequence_length_distribution.png duplication_levels.png
    do
        if [ ! -f ${images_dir}/${file} ] ; then
            echo "Warning: can't find ${images_dir}/${file}"
        else
            echo "\subfigure" >> ${latex_file}
            echo "{" >> ${latex_file}
            echo "    \\includegraphics[width=8cm]{${images_dir}/${file}}" >> ${latex_file}
            echo "}" >> ${latex_file}
        fi
    done

    echo "\\end{figure}" >> ${latex_file}

    echo "\\section*{\large{${header_prefix}${gz_filename}}}" >> ${latex_file}

    echo "\\subsection*{Summary}" >> ${latex_file};
    echo "\\begin{table}[h!]" >> ${latex_file}
    echo "{\\footnotesize" >> ${latex_file}
    echo "\\begin{tabular}{l l}" >> ${latex_file}
    grep -A 8 'Basic Statistics' ${dirname}/fastqc_data.txt | grep -A 7 'Filename' | perl -nae 'my @arr=split(/\t/); print $arr[0], " & ", $arr[1], "\\\\\n"' | sed 's/\%/\\%/g' | sed 's/_/\\_/g' >> ${latex_file}
    echo "\\end{tabular}" >> ${latex_file}
    echo "}" >> ${latex_file}
    echo "\\end{table}" >> ${latex_file}

    echo "\\subsection*{Module summary}" >> ${latex_file};
    echo "\\begin{table}[h!]" >> ${latex_file}
    echo "{\\footnotesize" >> ${latex_file}
    echo "\\begin{tabular}{l l l l}" >> ${latex_file}
    cat ${dirname}/fastqc_data.txt | grep '>>' | grep -v 'END_MODULE' | sed 's/>>//' | perl -nae 'my @arr=split(/\t/); $arr[1]=~s/\n//; print $arr[0], " & ", $arr[1], " \\\\\n";' >> ${latex_file}
    echo "\\end{tabular}" >> ${latex_file}
    echo "}" >> ${latex_file}
    echo "\\end{table}" >> ${latex_file}

    echo "\\subsection*{Overrepresented sequences}" >> ${latex_file};
    echo "\\begin{table}[h!]" >> ${latex_file}
    echo "{\\tiny" >> ${latex_file}
    echo "\\begin{tabular}{l l l l}" >> ${latex_file}
    awk '/Overrepresented sequences/,/END_MODULE/ {print}' ${dirname}/fastqc_data.txt | tail -n +3 | head -n -1 | head -n 45 | perl -nae 'my @arr=split(/\t/); print $arr[0], " & ", $arr[1]," & ", $arr[2], " & ", $arr[3], "\\\\\n"' | sed 's/\%/\\%/g' >> ${latex_file}
    echo "\\end{tabular}" >> ${latex_file}
    echo "}" >> ${latex_file}
    echo "\\end{table}" >> ${latex_file}
    echo "\\clearpage" >> ${latex_file}
}

# ----------------------------------------------------------------------
# Function: make_pdf
# Purpose:  Run pdflatex
# ----------------------------------------------------------------------
function make_pdf
{
    echo "--- Making PDF ---"
    pdflatex --file-line-error --shell-escape --output-directory ${output_dir} --interaction=batchmode ${latex_file}
    pdf_file=`echo ${latex_file} | sed s/.tex/.pdf/`
    echo "Written PDF file ${pdf_file}"
}

# ----------------------------------------------------------------------
# Function: attach_to_jira
# Purpose:  Attach PDF to JIRA ticket
# ----------------------------------------------------------------------
function attach_to_jira
{
    echo "--- Attaching to SEQOP-${seqop} ---"
    #echo curl -D- -k -u tgacpap:dff0LmqWKDgysG0RsIBFUgZrnsJfiMK9dqpzlhMcqSjj1uron9B0zZX70mv -X POST -H "X-Atlassian-Token: nocheck" -F "file=@${pdf_file};type=application/pdf"  http://jira.tgac.bbsrc.ac.uk:8080/rest/api/2.0.alpha1/issue/SEQOP-${seqop}/attachments
    curl -D- -k -u tgacpap:dff0LmqWKDgysG0RsIBFUgZrnsJfiMK9dqpzlhMcqSjj1uron9B0zZX70mv -X POST -H "X-Atlassian-Token: nocheck" -F "file=@${pdf_file};type=application/pdf" http://jira.tgac.bbsrc.ac.uk:8080/rest/api/latest/issue/SEQOP-${seqop}/attachments
    echo ""
    echo "Done"
}

# ----------------------------------------------------------------------
# Function: email_summary
# Purpose:  Email summary report
# ----------------------------------------------------------------------
function email_summary
{
    echo "FASTQC summary PDF attached." | mail -s "SEQOP-${seqop}" tgac.jira@tgac.ac.uk -- -f tgacpap@tgac
}

# ----------------------------------------------------------------------
# Main program
# ----------------------------------------------------------------------

# Loop through command line options
while getopts d:ehl:o:p:s: OPTION
do
    case $OPTION in
        d) fastqc_dir=$OPTARG;;
        e) email=1;;
        h) usage ; exit 1 ;;
        o) seqop=$OPTARG; find_run_dir $seqop; run_id=`basename ${run_dir}`;;
        l) latex_file=$OPTARG;;
        p) pap_folder=$OPTARG;;
        s) samplesheet=$OPTARG;;
    esac
done

if [ ${email} -eq 1 ] ; then
    if [ "${run_dir}" == "" ] ; then
        echo "Error: you must specify a -o option."
        exit 2
    fi
fi

if [ "${fastqc_dir}" == "" ] ; then
    if [ "${run_dir}" == "" ] ; then
        echo "Error: you must specify a -d or -o option."
        exit 2
    fi
fi

if [ "${run_dir}" != "" ] ; then
    if [ "${latex_file}" == "" ] ; then
        papdir=${run_dir}${TGACTOOLS_RUN_SUFFIX}/${pap_folder}
        stats_dir=${papdir}/Stats

        if [ ! -d ${stats_dir} ] ; then mkdir ${stats_dir} ; fi
    fi
elif [ "${latex_file}" == "" ] ; then
    echo "Error: you must specify a -l option."
    exit 2
fi


# Either output one FASTQC directory, or a whole run's worth
if [ ${run_dir} == "" ] ; then
    check_for_files ${fastqc_dir}
    output_latex_header
    output_latex_for_dir "" "${fastqc_dir}"
    output_latex_footer
    make_pdf
else
    # Find sample sheet file
    samplesheet=${run_dir}${TGACTOOLS_RUN_SUFFIX}/${samplesheet}

    if [ ! -f ${samplesheet} ] ; then
        echo "Error: Can't find sample sheet ${samplesheet}."
        exit -1
    fi

    echo "Sample sheet: ${samplesheet}"
    echo ""

    # Get list of projects
    projects=`cat ${samplesheet} | awk -F',' '{if ($1 != "FCID") print $10}' | sort | uniq`

    for project in ${projects}
    do
        echo "========== Project ${project} =========="

        output_dir=${stats_dir}/LaTeX_Project_${project}
        latex_file=${output_dir}/seqop${seqop}_${project}.tex
        if [ ! -d ${output_dir} ] ; then mkdir ${output_dir} ; fi
        output_latex_header

        libs=`cat ${samplesheet} | grep "${project}" | awk -F',' '{print $3}' | sort | uniq`
        for lib in ${libs}
        do
            echo "--- Library ${lib} ---"
            heading=`echo ${project} | sed 's/_/\\\_/g'`

            tempfilelist=`mktemp ~/filelist.XXXXX`
            for i in ${papdir}/Project_${project}/Sample_${lib}/Stats/*_fastqc
            do
            echo ${i} >> ${tempfilelist}
            done

            for fastqc_dir in `sort_by_lane.pl ${tempfilelist}`
            do
            echo "Parsing ${fastqc_dir}"
            check_for_files "${fastqc_dir}"
            output_latex_for_dir "${heading}\\\\" "${fastqc_dir}"
            done

            rm ${tempfilelist}
        done

        output_latex_footer
        make_pdf
        if [ ${email} -eq 1 ] ; then
            attach_to_jira
        fi
    done
fi
