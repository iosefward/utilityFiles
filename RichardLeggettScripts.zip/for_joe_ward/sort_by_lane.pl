#!/usr/bin/perl

# Sort file of PAP filenames.
#
# Format expected is:
#/data/sequencer_output/ngs-hiseq-3/130115_SN7001150_0129_BC16RGACXX/Data/Intensities/BaseCalls/PAP/Project_GEL_RaphaelMercier_INRA.RM.20120213.01/Sample_LIB2654/Stats/LIB2654_CCGTCC_L006_R1_fastqc/fastqc_data.txt
#/data/sequencer_output/ngs-hiseq-3/130115_SN7001150_0129_BC16RGACXX/Data/Intensities/BaseCalls/PAP/Project_GEL_RaphaelMercier_INRA.RM.20120213.01/Sample_LIB2654/Stats/LIB2654_CCGTCC_L006_R2_fastqc/fastqc_data.txt
#/data/sequencer_output/ngs-hiseq-3/130115_SN7001150_0129_BC16RGACXX/Data/Intensities/BaseCalls/PAP/Project_RCA_NicolaHarrison_EMR.NH.20120924.02rev/Sample_LIB2429/Stats/LIB2429_NoIndex_L005_R1_fastqc/fastqc_data.txt
#/data/sequencer_output/ngs-hiseq-3/130115_SN7001150_0129_BC16RGACXX/Data/Intensities/BaseCalls/PAP/Project_RCA_NicolaHarrison_EMR.NH.20120924.02rev/Sample_LIB2429/Stats/LIB2429_NoIndex_L005_R2_fastqc/fastqc_data.txt
#/data/sequencer_output/ngs-hiseq-3/130115_SN7001150_0129_BC16RGACXX/Data/Intensities/BaseCalls/PAP/Project_RCA_RobbieWaugh_JHI.RW20121106.02/Sample_LIB2642/Stats/LIB2642_CGATGT_L004_R1_fastqc/fastqc_data.txt
# PAP/Project_GEL_RaphaelMercier_INRA.RM.20120213.01/Sample_LIB2654/Stats/LIB2654_CCGTCC_L006_R2_fastqc/fastqc_data.txt
# PAP/Project_RCA_NicolaHarrison_EMR.NH.20120924.02rev/Sample_LIB2429/Stats/LIB2429_NoIndex_L005_R1_fastqc/fastqc_data.txt
# PAP/Project_RCA_NicolaHarrison_EMR.NH.20120924.02rev/Sample_LIB2429/Stats/LIB2429_NoIndex_L005_R2_fastqc/fastqc_data.txt
# PAP/Project_RCA_RobbieWaugh_JHI.RW20121106.02/Sample_LIB2642/Stats/LIB2642_CGATGT_L004_R1_fastqc/fastqc_data.txt
# etc.

use strict;
use warnings;

my $filename=$ARGV[0];
my @lines;
my $n_lines=0;

die "You must specify a filename" if not defined $filename;

open(MYFILE, $filename) or die "Can't open $filename\n";
while(<MYFILE>) {
    chomp(my $line = $_);
    $lines[$n_lines++] = $line;
}
close(MYFILE);

my @sorted_lines = sort mysort @lines;

for (my $i=0; $i<$n_lines; $i++) {
    print $sorted_lines[$i], "\n";
}

sub get_components {
    my $filename = $_[0];
    my $lane = 0;
    my $lib = 0;
    my $read = 0;

    my @arr=split(/\//, $filename);
    
    if ($arr[12] =~ /LIB(\d+)_(\S+)_L(\d+)_R(\d)/) {
        $lane = $3;
        $lib = $1;
        $read = $4;
    } elsif ($arr[12] =~ /(\d+)_LIB(\d+)_LDI(\d+)_(\S+)_L(\d+)_R(\d)/) {
        $lane = $5;
        $lib = $2;
        $read = $6;
    }

    return ($lane, $lib, $read);
}


sub mysort {
    my ($lane_a, $lib_a, $read_a) = get_components($a);
    my ($lane_b, $lib_b, $read_b) = get_components($b);

    if ($lane_a == $lane_b) {
        if ($lib_a == $lib_b) {
            return ($read_a <=> $read_b)
        } else {
            return ($lib_a <=> $lib_b);
        }
    } else {
        return ($lane_a <=> $lane_b);
    }
}    
