#!/bin/bash

if [ -z "${TGACTOOLS_RUN_DIR}" ] ; then
    echo "You must set TGACTOOLS_RUN_DIR"
    exit
fi

if [ -z "${TGACTOOLS_CONFIG_DIR}" ] ; then
    echo "You must set TGACTOOLS_CONFIG_DIR"
    exit
fi

seqop_file=${TGACTOOLS_CONFIG_DIR}/seqop_paths.txt
emails_file=${TGACTOOLS_CONFIG_DIR}/email_addresses.txt

# ----------------------------------------------------------------------
# Function: find_run_dir
# Purpose:  Find run directory from seqop number
# Returns:  run_dir set to be directory
# ----------------------------------------------------------------------
function find_run_dir
{
    seqop_number=$1

    awkstring="{ if (\$1 == ${seqop_number}) print \$2 "\n" }"
    numentries=`cat ${seqop_file} | awk "${awkstring}" | wc -l`

    if [ $numentries -eq 1 ] ; then
        entry=`cat ${seqop_file} | awk "${awkstring}"`
        if [[ "${entry}" == */* ]] ; then
            run_dir="${entry}"
        else
            run_dir="${TGACTOOLS_RUN_DIR}/${entry}"
        fi
    elif [ $numentries -eq 0 ] ; then
        echo "ERROR: No entry for seqop ${seqop_number}"
        exit 1
    else
        echo "ERROR: More than one entry for seqop ${seqop_number}"
        exit 1
    fi
}

# ----------------------------------------------------------------------
# Function: find_from_address
# Purpose:  Find username and make from: address for email 
# Returns:  from_address set to email address
# ----------------------------------------------------------------------
function find_from_address
{
    user=$1

    if [ "${user}" == "tgaclims" ] ; then
        echo "You need to specify your username with -u."
        exit 255
    fi

    awkstring="{ if (\$1 == \"${user}\") print \$2 "\n" }"
    numentries=`cat ${emails_file} | awk "${awkstring}" | wc -l`

    if [ ${numentries} -eq 1 ] ; then
        from_address=`cat ${emails_file} | awk "${awkstring}"`
    else
        from_address="${user}@tgac.ac.uk"
    fi
}

# ----------------------------------------------------------------------
# Function: make_temp_id
# Purpose:  Make a temporary 5 character ID for LSF 
# Returns:  temp_id set to the ID
# ----------------------------------------------------------------------
function make_temp_id
{
    currentdir=`pwd`
    cd ~
    temp_id=`mktemp XXXXX`
    rm -f ${tempid}
    cd ${currentdir}
}
