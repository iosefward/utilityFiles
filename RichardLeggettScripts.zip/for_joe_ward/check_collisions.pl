#!/usr/bin/perl -w

# Script:  check_collisions.pl
# Purpose: Check for barcode collisions on sample sheet
# Author:  Richard Leggett

use warnings;
use strict;

my $samplesheet = $ARGV[0];
my %samples;
my $current_lane = 0;

# Read lines from sample sheet and process each lane
open(SSFILE, $samplesheet) or die "Can't open $samplesheet\n";
<SSFILE>;
while(<SSFILE>) {
    chomp(my $line = $_);
    $line =~ s/\r//g;
    my @fields = split(/,/, $line);
    my $lane = $fields[1];
    my $barcode = $fields[4];
    
    if ($lane == $current_lane) {
        if (not defined $samples{$barcode}) {
            $samples{$barcode} = $line;
        } else {
            print "    ERROR: Barcode $barcode appears more than once in the sample sheet\n";
        }
    } else {
        if ($current_lane != 0) {
            process_lines();
        }
        
        $current_lane = $lane;
        print "\n==================== Processing lane $current_lane ==================== \n";

        # Clear the list of samples
        for (keys %samples)
        {
            delete $samples{$_};
        }
    
    }
}
close(SSFILE);

process_lines();




sub process_lines
{
    foreach my $barcode ( keys %samples ) {
        my @fields = split(/,/, $samples{$barcode});
        my $sample = $fields[2];
        my $project = $fields[9];
        
        if ($barcode ne "") {
            print "Checking barcode ", $barcode, " for sample ", $sample, " project ", $project, "\n";
            for (my $p=0; $p<length($barcode); $p++) {
                #print "  Generating mismatches for position $p:\n";
                foreach my $base ( 'A', 'C', 'G', 'T', 'N' ) {
                    if (substr($barcode, $p, 1) ne $base) {
                        my $mismatch_barcode = $barcode;
                        substr($mismatch_barcode, $p, 1) =~ s/\S/$base/;                    
                        #print "    Mismatch ", $mismatch_barcode, "\n";
                        if (defined $samples{$mismatch_barcode}) {
                            my @clash_fields = split(/,/, $samples{$mismatch_barcode});
                            my $clash_sample = $clash_fields[2];
                            my $clash_project = $clash_fields[9];
                            print "    WARNING: Mismatch code $mismatch_barcode generated for sample $sample project $project clashes with code from sample $clash_sample project $clash_project\n";
                        } else {
                            $samples{$mismatch_barcode} = $samples{$barcode};
                        }
                    }
                }
            }
        }
    }
}