#!/usr/bin/perl

use Getopt::Long;

my %barcodes;
my $infilename;
my $outfilename;
my $infilehandle;
my $outfilehandle;
my $helprequested;
my $maxcodes = 25;
my $mincount = 1000;
my $verbose = 0;

&GetOptions(
'in:s'       => \$infilename,
'out:s'      => \$outfilename,
'h'          => \$helprequested,
'maxcodes:i' => \$maxcodes,
'mincount:i' => \$mincount,
'verbose'    => \$verbose
);

if (defined $helprequested) {
    print "\n";
    print "parse_undetermined [-in <filename>] [-out <filename>]\n\n";
    print "Compiles list of unused barcodes in Undetermined_indices directory.\n";
    print "Input and output can be piped.\n";
    print "\n";
    print "Options:\n";
    print "-in <filename>	Name of input file (or from STDIN if not specified)\n";
    print "-out <filename>	Name of output file (or to STDOUT if not specified)\n";
    print "-maxcodes <int>      Maximum number of barcodes to output, or 0 for all (default 25)\n";
    print "-mincount <int>	Minimum count of barcode to display in results (default 1000)\n";
    print "-verbose";
    print "\n";
    print "Typical usage:\n";
    print "1. gunzip <filename.fq.gz> | parse_undetermined.pl\n";
    print "2. gunzip <directory/*.gz> | parse_undetermined.pl\n";
    print "3. parse_undetermined.pl -in <filename.fq>\n";
    print "\n";    
    exit;
}

if (defined $infilename) {
    open($infilehandle, $infilename) or die "Can't open $infilename\n";
} else {
    $infilehandle = STDIN;
}

if (defined $outfilename) {
    open($outfilehandle, ">".$outfilename) or die "Can't open $outfilename\n";
} else {
    $outfilehandle = STDOUT;
}

print "Reading FASTQ data...\n" if $verbose;
print "Maxcodes: $maxcodes\n" if $verbose;

while(<$infilehandle>) {
    chomp(my $line = $_);

    # Example ID: @HWI-ST319:225:C0KR9ACXX:2:1101:6604:2126 1:N:0:AAAACG
    if ($line =~ /^\@(\S+) (\S+)\:(\S{6,16})$/) {
        my $code = $3;
    
        if (defined $barcodes{$code}) {
            $barcodes{$code}++;
        } else {
            $barcodes{$code} = 1;
        }
    }
}

if (defined $infilename) {
    close($infilehandle);
}

my $n_out=0;

foreach $code (sort {$barcodes{$b} <=> $barcodes{$a}} keys %barcodes)
{
    my $count = $barcodes{$code};

    if ($count >= $mincount) {
        print $outfilehandle $code, "\t", $barcodes{$code}, "\n";
        $n_out++;
    }

    last if (($maxcodes != 0) && ($n_out == $maxcodes));
}

if ($n_out == 0) {
    print $outfilehandle "No barcodes with count >", $mincount, ".\n";
}


if (defined $outfilename) {
    close($outfilehandle);
}

print "Done\n" if $verbose;
