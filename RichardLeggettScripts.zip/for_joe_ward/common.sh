#!/bin/bash
include preferences.sh


#TODO: Find a way to make a "general trap" When using this function, make sure you trap the folder to delete

function get_tmp_folder {
	if [ -z "$TMPDIR" ]; then		
		export TMPDIR="/tmp"
	fi
	mkdir -p $TMPDIR/$USER
#	echo "TEMPDIR: $TMPDIR" >&2
	
	if [[ -z "$TMPFOLDER"  || ! -d $TMPFOLDER ]]; then
		#export TMPFOLDER=`mktemp -d -t $TMPDIR`
		export TMPFOLDER=`mktemp -d -t $USER.XXXX`
		log_line "Just set up the temp folder as $TMPFOLDER"
#		echo "Using $TMPFOLDER as tmp" >&2

	fi

	
 	echo $TMPFOLDER
	
}

function  get_number_of_threads {
	if [ -z "$THREADS" ]; then
		export THREADS=1
	fi
	echo $THREADS
}

function exit_on_error {
	echo "$1" >&2
	exit 255
}

function log_line {
	echo $(date) "$1" >&2
	
}

function get_free_memmory {
	echo "500000000"
}

function is_gz {
	local read_name=$1
	gz="0"
	if [[ $(echo $read_name | grep .gz$ ) ]];then
		gz="1"
	fi
	echo $gz
}

function is_fastq {
	local read_name=$1
	fq="0"
	if [[ $(echo $r | grep .fq ) ]];then
		fq="1"
	fi
	if [[ $(echo $r | grep .fastq ) ]];then
		fq="1"
	fi
	echo $fq
}

function submit {
	local cmd=$1
	
	if [ -z "$VERBOSE" ]; then
		log_line "Submitting:  $cmd "
	fi
	
	#TODO change this to something more serious
	if [ ! -z "$LSF_LIBDIR" ]; then
		bsub -n $THREADS -o ~/lsf_common_logs -R "span[hosts=1]" -q ngs_processing  "$cmd"
	else
		$cmd
	fi
}

function validate_env {
	if [ ! -z "$LSF_LIBDIR" ]; then
		if [ ! -f "$REFERENCES" ]; then
			brequeue $LSB_JOBID
			exit 
		fi
	fi
}

#This function returns a list of pairs (one per line), separated by colons. 
#It assumes the file convention in casava 1.8. 
#We have to make functions for other casava versions, or other types of pairs. 
function parse_casava_1.8_pairs {
	local folder=$1
	ls $folder | grep fastq | sed 's/\./_/g'|sort -t_ -k 1,1 -k2,2 -k3,3 -k5,5 -k4,4 | sed -e 's/_/\./5' | sed -e 's/_/\./5' | awk '{if(NR%2==0){print r1":"$0}else{r1=$0} }'
}

#This function validates that the common fields in the filename of a casava pair are consistent. 
function validate_casava_1_8_pairs {
	local read1=`echo $1|sed 's/\./_/g'`
	local read2=`echo $2|sed 's/\./_/g'`
	
	local fields1=(${read1//_/ })
	local fields2=(${read2//_/ })
	
	for f in 0 1 2  4; do
		if [ "${fields1[$f]}" != "${fields2[$f]}" ]; then
			log_line "$read1 and $read2 don't look like casava 1.8 pairs"
			exit -1
		fi
	done	
}

#validate_env
